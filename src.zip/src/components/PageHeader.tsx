import { IonHeader, IonTitle, IonToolbar } from '@ionic/react';
import Searchbar from './SearchBar'

interface ContainerProps {
  name: string;
}

const PageHeader: React.FC<ContainerProps> = ({ name }) => {
  return (
    <IonHeader>
        <IonToolbar>
          <IonTitle class="ion-text-center" style={{marginTop:"10px"}}>{name}</IonTitle>
          <Searchbar name="name"></Searchbar>
        </IonToolbar>
      </IonHeader>
  );
};

export default PageHeader;
