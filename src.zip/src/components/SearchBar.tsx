import React from 'react';
import { IonSearchbar } from '@ionic/react';

interface ContainerProps {
    name: string;
  }
  
  const Searchbar: React.FC<ContainerProps> = ({ name }) => {
    return (
      <IonSearchbar showClearButton="focus" placeholder="Placeholder" style={{margin: "12px 0px 0px 0px",
    padding: "0px"}}></IonSearchbar>
  );
}

export default Searchbar;